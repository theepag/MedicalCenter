package runner;

import entities.ItemDetails;
import java.util.List;
import org.hibernate.Query;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EditItem {
    
    public static int addItem(ItemDetails f){  
    
    int i=0;  
    Session session=new Configuration().  
     configure().buildSessionFactory().openSession();  

     Transaction t=session.beginTransaction();  

     i=(Integer)session.save(f);  

     t.commit();  
     session.close();  

     return i;  
     
    } 
    

    public static List<ItemDetails> getAllItem() {

        Session session = new Configuration().configure().buildSessionFactory().openSession();

        Query query = session.createQuery("from ItemDetails");

        List<ItemDetails> list = query.list();

        session.close();
        
        return list;
      
    }
    
    
    
    public static void updateItem(ItemDetails f){
        Session session = new Configuration().configure().buildSessionFactory().openSession();

        session.beginTransaction();
        
        //session.update(f);
        ItemDetails x=(ItemDetails)session.merge(f);

        session.saveOrUpdate(x);
        
        session.getTransaction().commit();
        
        session.close();
    }

}
